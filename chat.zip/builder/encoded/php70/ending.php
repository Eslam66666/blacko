<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

if (!defined("BOOM")) {
    exit;
}
echo "<div class=\"page_element\">\r\n\t<h3 class=\"install_h3\"><i class=\"fa fa-check success\"></i> Installation completed</h3>\r\n\t<p>Congratulation chat is successfully installed.</p><br/>\r\n\t<button id=\"install_done\" onclick=\"endInstall();\" type=\"button\" class=\"save_admin reg_button ok_btn\"><i class=\"fa fa-comment\"></i> Go to chat</button>\r\n</div>";

?>