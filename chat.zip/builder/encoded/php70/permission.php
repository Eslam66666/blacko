<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

if (!defined("BOOM")) {
    exit;
}
$installed = "<span class=\"perm_state success\">Installed</span>";
$not_installed = "<span class=\"perm_state error\">Not installed</span>";
$writable = "<span class=\"perm_state success\">Writable</span>";
$not_writable = "<span class=\"perm_state error\">Not writable</span>";
$permission = 1;
$check_upload = $writable;
$check_database = $writable;
$check_avatar = $writable;
$check_cover = $writable;
$check_gd = $installed;
$check_php = $installed;
$check_curl = $installed;
$check_zip = $installed;
$check_mbstring = $installed;
if (!is_writable(dirname(BOOM_PATH . "/avatar"))) {
    $check_avatar = $not_writable;
    $permission = 0;
}
if (!is_writable(dirname(BOOM_PATH . "/cover"))) {
    $check_cover = $not_writable;
    $permission = 0;
}
if (!is_writable(BOOM_PATH . "/system/database.php")) {
    $check_database = $not_writable;
    $permission = 0;
}
if (!is_writable(dirname(BOOM_PATH . "/upload/"))) {
    $check_upload = $not_writable;
    $permission = 0;
}
if (!extension_loaded("gd") && !function_exists("gd_info")) {
    $check_gd = $not_installed;
    $permission = 0;
}
if (!version_compare(PHP_VERSION, "5.6.0", ">=")) {
    $check_php = $not_installed;
    $permission = 0;
}
if (!function_exists("curl_init")) {
    $check_curl = $not_installed;
    $permission = 0;
}
if (!extension_loaded("zip")) {
    $check_zip = $not_installed;
    $permission = 0;
}
if (!extension_loaded("mbstring")) {
    $check_mbstring = $not_installed;
    $permission = 0;
}
if ($permission == 1) {
    echo 1;
    exit;
}
echo "<div class=\"page_element\">\r\n\t<p class=\"install_h3\">System requirements</p>\r\n\t<ul id=\"check_ul\" class=\"sub_install\">\r\n\t\t<li>Php 5.6 - 7.2 version ";
echo $check_php;
echo "</li>\r\n\t\t<li>GD library ";
echo $check_gd;
echo "</li>\r\n\t\t<li>Curl ";
echo $check_curl;
echo "</li>\r\n\t\t<li>Zip extension ";
echo $check_zip;
echo "</li>\r\n\t\t<li>Mbstring extension ";
echo $check_mbstring;
echo "</li>\r\n\t\t<li>system / database.php ";
echo $check_database;
echo "</li>\r\n\t\t<li>avatar folder ";
echo $check_avatar;
echo "</li>\r\n\t\t<li>cover folder ";
echo $check_avatar;
echo "</li>\r\n\t\t<li>upload folder ";
echo $check_upload;
echo "</li>\r\n\t</ul>\r\n\t<button id=\"check_permission\" onclick=\"checkPermission();\" type=\"button\" class=\"save_admin reg_button ok_btn\">Continue</button>\r\n</div>\r\n\r\n";

?>