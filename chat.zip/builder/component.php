<?php
require_once('config_install.php');
require('encoded/' . $boom_version . '/' . basename(__FILE__));
?>	