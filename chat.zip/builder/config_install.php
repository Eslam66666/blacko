<?php
require(__DIR__ . '/../system/database.php');
require(__DIR__ . '/../system/variable.php');
require(__DIR__ . '/../system/function.php');
require(__DIR__ . '/../system/function_2.php');
require(__DIR__ . '/../system/config_version.php');
?>