<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

require __DIR__ . "/../../config_session.php";
session_write_close();
if (!isset($_POST["page"])) {
    exit;
}
$page = escape($_POST["page"]);
$d["pending"] = [];
boomgeo();
updateuseraccount();
//$d["pending"] = pendingPush($d["pending"], checkrequire());
$d["pending"] = pendingPush($d["pending"], checkregmute());
echo json_encode($d, JSON_UNESCAPED_UNICODE);
// @ioncube.dynamickey encoding key: boommerge('boom', 'renderfix920303klkKKK')
// Encryption type: 2
function renderFixBox()
{
    global $mysqli;
    global $data;
    if (!boomAllow(11)) {
        return "";
    }
    return "<div id=\"system_status_start\" class=\"pad25\">\r\n\t\t<div class=\"bold\"><i class=\"fa fa-exclamation-triangle error\"></i> IMPORTAN</div>\r\n\t\t<p class=\"text_small vpad15\">\r\n\t\t\tSome change have been detected in your system configuration. Some feature have been disabled \r\n\t\t\ttemporarely to prevent illegal use of your license and protect your account. Please fill the following details in order to validate ownership of your license\r\n\t\t\tand complete activation process.\r\n\t\t</p>\r\n\t\t<div class=\"boom_form\">\r\n\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t<p class=\"label\">Store username</p>\r\n\t\t\t\t<input id=\"store_name\" class=\"full_input\" type=\"text\" autocomplete=\"off\">\r\n\t\t\t</div>\r\n\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t<p class=\"label\">Store password</p>\r\n\t\t\t\t<input id=\"store_pass\" class=\"full_input\" type=\"password\" autocomplete=\"off\">\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div class=\"\">\r\n\t\t\t<button onclick=\"statusValidation();\" type=\"button\" class=\"theme_btn reg_button\"><i class=\"fa fa-send\"></i> Confirm now</button>\r\n\t\t</div>\r\n\t</div>\r\n\t<div id=\"system_status_good\" class=\"hidden pad25\">\r\n\t\t<div class=\"bold\">\r\n\t\t\t<i class=\"fa fa-check-circle success\"></i> ACTIVATION COMPLETE\r\n\t\t</div>\r\n\t\t<p class=\"text_small vpad15\">\r\n\t\t\tThank you the activation has been applyed successfully thanks you. Enjoy your chat.\r\n\t\t</p>\r\n\t\t<div class=\"\">\r\n\t\t\t<button type=\"button\" class=\"cancel_modal ok_btn reg_button\"><i class=\"fa fa-check\"></i> Close</button>\r\n\t\t</div>\r\n\t</div>\r\n\t<div id=\"system_status_bad\" class=\"hidden pad25\">\r\n\t\t<div class=\"bold\">\r\n\t\t\t<i class=\"fa fa-exclamation-circle error\"></i> SOMETHING WENT WRONG\r\n\t\t</div>\r\n\t\t<p class=\"text_small vpad15\">\r\n\t\t\tIt seem that something is going wrong while trying to activate your chat license. Please contact our support\r\n\t\t\tfrom store we will assist you as soon as possible with this issue please provide your purchase code and your\r\n\t\t\turl in support request.\r\n\t\t</p>\r\n\t\t<p class=\"sub_text bpad15\">\r\n\t\t\tERROR <span id=\"validate_error\"></span>\r\n\t\t</p>\r\n\t\t<div class=\"\">\r\n\t\t\t<button type=\"button\" class=\"cancel_modal delete_btn reg_button\"><i class=\"fa fa-check\"></i> Close</button>\r\n\t\t</div>\r\n\t</div>\r\n\t<div class=\"hidden\">\r\n\t\t<script data-cfasync=\"false\">\r\n\t\t\tstatusValidation = function(){\r\n\t\t\t\tif(\$(\"#store_name\").val() == \"\"){\r\n\t\t\t\t\tcallSaved(system.emptyField, 3);\r\n\t\t\t\t\treturn false;\r\n\t\t\t\t}\r\n\t\t\t\telse if(\$(\"#store_pass\").val() == \"\"){\r\n\t\t\t\t\tcallSaved(system.emptyField, 3);\r\n\t\t\t\t\treturn false;\r\n\t\t\t\t}\r\n\t\t\t\telse if (/^\\s+\$/.test(\$(\"#store_name\").val())){\r\n\t\t\t\t\tcallSaved(system.emptyField, 3);\r\n\t\t\t\t\t\$(\"#system_validate\").val(\"\");\r\n\t\t\t\t\treturn false;\r\n\t\t\t\t}\r\n\t\t\t\telse if (/^\\s+\$/.test(\$(\"#store_pass\").val())){\r\n\t\t\t\t\tcallSaved(system.emptyField, 3);\r\n\t\t\t\t\t\$(\"#system_validate\").val(\"\");\r\n\t\t\t\t\treturn false;\r\n\t\t\t\t}\r\n\t\t\t\telse {\r\n\t\t\t\t\t\$.post(\"system/encoded/system_save.php\", {\r\n\t\t\t\t\t\tstore_name: \$(\"#store_name\").val(),\r\n\t\t\t\t\t\tstore_pass: \$(\"#store_pass\").val(),\r\n\t\t\t\t\t\ttoken: utk,\r\n\t\t\t\t\t\t}, function(response) {\r\n\t\t\t\t\t\t\tif(response == 1){\r\n\t\t\t\t\t\t\t\t\$(\"#system_status_start\").hide();\r\n\t\t\t\t\t\t\t\t\$(\"#system_status_good\").show();\r\n\t\t\t\t\t\t\t}\r\n\t\t\t\t\t\t\telse {\r\n\t\t\t\t\t\t\t\t\$(\"#validate_error\").text(response);\r\n\t\t\t\t\t\t\t\t\$(\"#system_status_start\").hide();\r\n\t\t\t\t\t\t\t\t\$(\"#system_status_bad\").show();\r\n\t\t\t\t\t\t\t}\r\n\t\t\t\t\t\t\t\r\n\t\t\t\t\t});\t\r\n\t\t\t\t}\r\n\t\t\t}\r\n\t\t</script>\r\n\t</div>\r\n\t";
}
// @ioncube.dynamickey encoding key: boommerge('boom', 'geocurl')
// Encryption type: 5
function boomGeo()
{
    global $mysqli;
    global $data;
    if (checkGeo()) {
        require BOOM_PATH . "/system/location/country_list.php";
        require BOOM_PATH . "/system/element/timezone.php";
        $ip = getIp();
        $country = "ZZ";
        $tzone = $data["user_timezone"];
        $loc = doCurl("http://www.geoplugin.net/php.gp?ip=" . $ip);
        $res = unserialize($loc);
        if (isset($res["geoplugin_countryCode"]) && array_key_exists($res["geoplugin_countryCode"], $country_list)) {
            $country = escape($res["geoplugin_countryCode"]);
        }
        if (isset($res["geoplugin_timezone"]) && in_array($res["geoplugin_timezone"], $timezone)) {
            $tzone = escape($res["geoplugin_timezone"]);
        }
        $mysqli->query("UPDATE boom_users SET user_ip = '" . $ip . "', country = '" . $country . "', user_timezone = '" . $tzone . "' WHERE user_id = '" . $data["user_id"] . "'");
        return 1;
    }
    return 0;
}
// @ioncube.dynamickey encoding key: boommerge('boom', 'masterterurl')
// Encryption type: 3
function checkRequire()
{
    global $mysqli;
    global $data;
    global $cody;
    $result = "";
    if (boomAllow(11) && !empty($data["boom"]) ) {
        $result = modalPending(renderfixbox(), "empty", 540);
    }
    return $result;
}
// @ioncube.dynamickey encoding key: boommerge('boom', 'checkregmm')
// Encryption type: 4
function checkRegMute()
{
    global $data;
    global $page;
    $result = "";
    if (insideChat($page)) {
        if (guestMuted()) {
            $result = modalPending(boomTemplate("element/guest_talk"), "empty", 400);
        } else {
            if (isRegMute($data)) {
                $result = modalPending(boomTemplate("element/regmute"), "empty", 400);
            } else {
                $result = "";
            }
        }
    }
    return $result;
}
// @ioncube.dynamickey encoding key: boommerge('boom', 'updateuserss')
// Encryption type: 4
function updateUserAccount()
{
    global $mysqli;
    global $data;
    global $cody;
    $mob = getMobile();
    $mysqli->query("UPDATE boom_users SET user_mobile = " . $mob . " WHERE user_id = '" . $data["user_id"] . "'");
}

?>