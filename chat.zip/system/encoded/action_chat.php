<?php
require('../config_version.php');
require($boom_version . '/' . basename(__FILE__));
?>