<?php
// you can edit these lines to configure new setting for your chat
$DB_HOST = "localhost";
$DB_USER = "id21093495_chatmra_mr";
$DB_PASS = "01122aA@";
$DB_NAME = "id21093495_chatmra_mr";

// Please do not modify this line post installation
$encryption = "44ffB426cb-69eb80e2391934b7O-5bM0-7Oc5e";
$check_install = 1;
?>