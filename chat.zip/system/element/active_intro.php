<div class="active_user">
	<img alt="<?php echo $boom['user_name']; ?>" title="<?php echo $boom['user_name']; ?>" class="active_avatar" src="<?php echo myAvatar($boom['user_tumb']); ?>"/>
</div>