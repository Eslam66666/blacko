<div class="page_drop_control page_menu_item">
	<div class="page_menu_icon">
		<i class="fa fa-<?php echo $boom['icon']; ?> menup"></i>
	</div>
	<div class="page_menu_text">
		<?php echo $boom['txt']; ?>
	</div>
	<div class="page_drop_icon">
		<i class="fa fa-chevron-down pclose"></i>
		<i class="fa fa-chevron-up popen"></i>
	</div>
</div>
<div class="page_drop">
	<?php echo $boom['drop']; ?>
</div>