<html>
<head>
</head>
<body>
	<div>
		<?php echo $boom['content']; ?>
	</div>
	<br />
	<div>
		<?php echo $boom['signature']; ?>
	</div>
</body>
</html>