<div onclick="loadLanguage('<?php echo $boom; ?>');" class="list_element btable lang_box">
	<div class="bcell_mid lang_flag_box">
		<img alt="<?php echo $boom; ?> flag" class="lang_flag" src="system/language/<?php echo $boom; ?>/flag.png"/> 
	</div>
	<div class="bcell_mid lang_lang">
		<?php echo $boom; ?>
	</div>
</div>