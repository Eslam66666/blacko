vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|03 Oct 2020 06:56:08 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|DESKTOP-V0VV0JD\\القلم
vti_modifiedby:SR|DESKTOP-V0VV0JD\\القلم
vti_timecreated:TR|03 Oct 2020 06:56:08 -0000
vti_cacheddtm:TX|03 Oct 2020 06:56:08 -0000
vti_filesize:IR|5677
vti_cachedtitle:SR|<?php echo $page['page_title']; ?>
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|default_images/icon.png< Q|js/fancybox/jquery.fancybox.css< Q|css/font-awesome.min.css< Q|css/selectboxit.css< Q|js/jqueryui/jquery-ui.min.css< Q|css/main.css< Q|control/login/< Q|css/colors.css< Q|css/themes/< Q|css/responsive.css< S|js/jquery-1.11.2.min.js< S|system/language/< S|js/fancybox/jquery.fancybox.js< S|js/jqueryui/jquery-ui.min.js< S|js/global.min.js< S|js/function_split.js< S|https://google.com/recaptcha/api.js S|js/function_logged.js< Q|css/rtl.css< Q|css/custom.css<
vti_cachedsvcrellinks:VX|NHUS|control/default_images/icon.png< NQUS|control/js/fancybox/jquery.fancybox.css< NQUS|control/css/font-awesome.min.css< NQUS|control/css/selectboxit.css< NQUS|control/js/jqueryui/jquery-ui.min.css< NQUS|control/css/main.css< NQUS|control/control/login/< NQUS|control/css/colors.css< NQUS|control/css/themes/< NQUS|control/css/responsive.css< NSUS|control/js/jquery-1.11.2.min.js< NSUS|control/system/language/< NSUS|control/js/fancybox/jquery.fancybox.js< NSUS|control/js/jqueryui/jquery-ui.min.js< NSUS|control/js/global.min.js< NSUS|control/js/function_split.js< NSSS|https://google.com/recaptcha/api.js NSUS|control/js/function_logged.js< NQUS|control/css/rtl.css< NQUS|control/css/custom.css<
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=content-type text/html;\\ charset=utf-8 description <?php\\ echo\\ $page['page_description'];\\ ?> keywords <?php\\ echo\\ $page['page_keyword'];\\ ?> viewport width=device-width,\\ initial-scale=1.0,\\ maximum-scale=1.0,\\ user-scalable=0
vti_charset:SR|utf-8
vti_title:SR|<?php echo $page['page_title']; ?>
vti_backlinkinfo:VX|
