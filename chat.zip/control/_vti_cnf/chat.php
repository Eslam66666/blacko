vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|05 Nov 2020 14:31:24 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|DESKTOP-V0VV0JD\\القلم
vti_modifiedby:SR|DESKTOP-V0VV0JD\\القلم
vti_timecreated:TR|05 Nov 2020 14:31:24 -0000
vti_cacheddtm:TX|05 Nov 2020 14:31:24 -0000
vti_filesize:IR|15828
vti_cachedlinkinfo:VX|S|< S|< S|emoticon_icon/base_emo.png S|default_images/icons/upload.svg S|default_images/icons/pencil.svg S|default_images/icons/upload.svg S|emoticon_icon/base_emo.png S|js/function_main.js< S|js/function_menu.js< S|js/function_player.js<
vti_cachedsvcrellinks:VX|DSUS|control/< DSUS|control/< NSUS|control/emoticon_icon/base_emo.png NSUS|control/default_images/icons/upload.svg NSUS|control/default_images/icons/pencil.svg NSUS|control/default_images/icons/upload.svg NSUS|control/emoticon_icon/base_emo.png NSUS|control/js/function_main.js< NSUS|control/js/function_menu.js< NSUS|control/js/function_player.js<
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1256
vti_backlinkinfo:VX|
