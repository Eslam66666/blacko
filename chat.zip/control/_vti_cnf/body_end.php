vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|03 Oct 2020 15:08:00 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|DESKTOP-V0VV0JD\\القلم
vti_modifiedby:SR|DESKTOP-V0VV0JD\\القلم
vti_timecreated:TR|03 Oct 2020 15:08:00 -0000
vti_cacheddtm:TX|03 Oct 2020 15:08:00 -0000
vti_filesize:IR|80
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1256
vti_backlinkinfo:VX|
